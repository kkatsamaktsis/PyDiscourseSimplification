from enum import Enum, auto


class ProcessingType(Enum):
    SEPARATE = auto()
    WHOLE = auto()
