class TimeInformation:

    def __init__(self, value: str = None):
        self.value = value
